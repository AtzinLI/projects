<!DOCTYPE html>
<html>
    <head>
        <title>CRUD</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="<?php echo e(asset('css/uikit/uikit.min.css')); ?>" rel="stylesheet">
        <script type="text/javascript" src="<?php echo asset('js/uikit/uikit.min.js'); ?>" async></script>
        <script type="text/javascript" src="<?php echo asset('js/uikit/uikit-icons.min.js'); ?>" async></script>
        <style>
            body {
                margin: 30px;
                padding: 30px;
            }

            a {
                text-decoration: none;
            }

            a:hover { color: white; 
            
            }

            .registrar {
                background-color: #28B463;
                color: white;
            }

            .registrar:hover {
                background-color: #239B56;
            }
        </style>
    </head>
    <body class="uk-background-muted">
        <div>
            <div class="uk-text-center ">
                <h3 class="uk-text-bold">LISTA USUARIOS</h3>
            </div>
            <div>
                <a class="uk-button registrar" href="<?php echo e(url('/registrar')); ?>" >Agregar</a>
            </div>
                <table class="uk-table uk-table-hover uk-table-divider">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Edad</th>
                            <th>Genero</th>
                            <th>Direcciòn</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($usuario->nombre); ?></th>
                            <td><?php echo e($usuario->edad); ?></th>
                            <td><?php echo e($usuario->genero == false ? 'Femenino' : 'Masculino'); ?></th>
                            <td><?php echo e($usuario->getDireccion()); ?></th>
                            <td>
                                <a class="uk-icon-button uk-button-primary uk-margin-small-right" uk-icon="pencil" href="<?php echo e(url('/editar/'.$usuario->id)); ?>"></a>
                                <button uk-toggle="target: #my-id-<?php echo e($usuario->id); ?>" type="button" class="uk-icon-button uk-margin-small-right uk-button-danger" uk-icon="trash"></button>
                                <div id="my-id-<?php echo e($usuario->id); ?>" uk-modal>
                                    <div class="uk-modal-dialog uk-modal-body">
                                        <h2 class="uk-text-large">¿ Desea borrar a <?php echo e($usuario->nombre); ?> ?</h2>
                                        <form action="<?php echo e(url('/eliminar/'.$usuario->id)); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="uk-modal-footer uk-text-right">
                                            <button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
                                            <button type="submit" class="uk-button uk-button-primary">Borrar</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
        </div>
    </body>
</html><?php /**PATH C:\Users\atzin\cwea\resources\views/lista.blade.php ENDPATH**/ ?>