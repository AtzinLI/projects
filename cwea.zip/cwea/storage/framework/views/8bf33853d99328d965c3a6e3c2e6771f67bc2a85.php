<!DOCTYPE html>
<html>
    <head>
        <title>CRUD</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="<?php echo e(asset('css/uikit/uikit.min.css')); ?>" rel="stylesheet">
        <script type="text/javascript" src="<?php echo asset('js/uikit/uikit.min.js'); ?>" async></script>
        <script type="text/javascript" src="<?php echo asset('js/uikit/uikit-icons.min.js'); ?>" async></script>
        <style>
            body {
                margin: 30px;
                padding: 30px;
            }

            a {
                text-decoration: none;
            }

            a:hover { color: white; 
            
            }

            .registrar {
                background-color: #28B463;
                color: white;
            }

            .registrar:hover {
                background-color: #239B56;
            }
        </style>
    </head>
    <body class="uk-background-muted">
        <div>
            <div class="uk-text-center ">
                <h3 class="uk-text-bold">REGISTRAR USUARIO</h3>
            </div>
            <form class="uk-form-stacked" action="<?php echo e(url('/editarUsuario/'.$usuario->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>


                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-text">Nombre:</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-stacked-text" type="text" value="<?php echo e($usuario->nombre); ?>" name="nombre">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-select">Edad:</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-stacked-text" type="number" value="<?php echo e($usuario->edad); ?>" name="edad">
                    </div>
                </div>

                <div class="uk-margin">
                    <div class="uk-form-label">Genero:</div>
                    <div class="uk-form-controls uk-margin uk-grid-small uk-child-width-auto uk-grid">
                    <?php if($usuario->genero == false): ?>
                        <label><input class="uk-radio" type="radio" name="genero" value="0" checked> Femenino</label><br>
                        <label><input class="uk-radio" type="radio" name="genero" value="1"> Masculino</label>
                    <?php else: ?>
                        <label><input class="uk-radio" type="radio" name="genero" value="0"> Femenino</label><br>
                        <label><input class="uk-radio" type="radio" name="genero" value="1" checked> Masculino</label>
                    <?php endif; ?>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-text">Calle:</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-stacked-text" type="text" value="<?php echo e($direccion->calle); ?>" name="calle">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-select">Nùmero:</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-stacked-text" type="number" value="<?php echo e($direccion->numero); ?>" name="num">
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-text">Colonia:</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-stacked-text" type="text" value="<?php echo e($direccion->colonia); ?>" name="colonia">
                    </div>
                </div>

                <div class="uk-text-center ">
                    <button type="submit" class="uk-button uk-button-primary uk-margin-top">Editar</button>
                    <a class="uk-button uk-button-danger uk-margin-top uk-margin-left" href="<?php echo e(url('/')); ?>">Cancelar</a>
                </div>

            </form>
        </div>
    </body>
</html><?php /**PATH C:\Users\atzin\cwea\resources\views/editar.blade.php ENDPATH**/ ?>