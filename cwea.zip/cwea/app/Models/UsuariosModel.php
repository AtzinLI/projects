<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\DireccionesModel;

class UsuariosModel extends Model {
    use HasFactory;

    protected $table = 'usuarios';

    protected $fillable = [
        'nombre',
        'edad',
        'genero',
    ];

    public function getDireccion() {
        $direccion = DireccionesModel::where('id_usuario', $this->id)->first();
        return $direccion->calle.' '.$direccion->numero.' '.$direccion->colonia;
    }
}
