<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UsuariosModel;
use App\Models\DireccionesModel;

class UsuariosController extends Controller {

    public function index() {
        $usuarios = UsuariosModel::paginate(10);
        return view('lista', ['usuarios' => $usuarios] );
    }

    public function create() {
        return view('registrar');
    }

    public function editar($id) {
        $usuario = UsuariosModel::find($id);
        $direccion = DireccionesModel::where('id_usuario', $usuario->id)->first();
        return view('editar', ['usuario' => $usuario, 'direccion' => $direccion]);
    }

    public function registrarUsuario(Request $request) {
        $datosUsuario=request()->all();
        $usuario = UsuariosModel::create([
            'nombre' => $datosUsuario['nombre'],
            'edad' => $datosUsuario['edad'],
            'genero' => $datosUsuario['genero'],

        ]); 

        DireccionesModel::create([
            'calle' => $datosUsuario['calle'],
            'numero' => $datosUsuario['num'],
            'colonia' => $datosUsuario['colonia'],
            'id_usuario' => $usuario->id,
        ]); 

        return redirect('/');
    }

    public function eliminarUsuario($id) {

        DireccionesModel::where('id_usuario', $id)->delete();
        UsuariosModel::where('id', $id)->delete();

        return redirect('/');
    }

    public function editarUsuario(Request $request, $id) {

        $usuario = UsuariosModel::find($id);
        $direccion = DireccionesModel::where('id_usuario', $usuario->id)->first();
        $datosUsuario=request()->all();

        $usuario->nombre = $datosUsuario['nombre'];
        $usuario->edad = $datosUsuario['edad'];
        $usuario->genero = $datosUsuario['genero'];
        $direccion->calle = $datosUsuario['calle'];
        $direccion->numero = $datosUsuario['num'];
        $direccion->colonia = $datosUsuario['colonia'];

        $usuario->save();
        $direccion->save();

        return redirect('/');
    }
}
