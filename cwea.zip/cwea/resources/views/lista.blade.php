<!DOCTYPE html>
<html>
    <head>
        <title>CRUD</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="{{ asset('css/uikit/uikit.min.css') }}" rel="stylesheet">
        <script type="text/javascript" src="{!! asset('js/uikit/uikit.min.js') !!}" async></script>
        <script type="text/javascript" src="{!! asset('js/uikit/uikit-icons.min.js') !!}" async></script>
        <style>
            body {
                margin: 30px;
                padding: 30px;
            }

            a {
                text-decoration: none;
            }

            a:hover { color: white; 
            
            }

            .registrar {
                background-color: #28B463;
                color: white;
            }

            .registrar:hover {
                background-color: #239B56;
            }
        </style>
    </head>
    <body class="uk-background-muted">
        <div>
            <div class="uk-text-center ">
                <h3 class="uk-text-bold">LISTA USUARIOS</h3>
            </div>
            <div>
                <a class="uk-button registrar" href="{{ url('/registrar') }}" >Agregar</a>
            </div>
                <table class="uk-table uk-table-hover uk-table-divider">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Edad</th>
                            <th>Genero</th>
                            <th>Direcciòn</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($usuarios as $usuario)
                        <tr>
                            <td>{{$usuario->nombre}}</th>
                            <td>{{$usuario->edad}}</th>
                            <td>{{$usuario->genero == false ? 'Femenino' : 'Masculino'}}</th>
                            <td>{{$usuario->getDireccion()}}</th>
                            <td>
                                <a class="uk-icon-button uk-button-primary uk-margin-small-right" uk-icon="pencil" href="{{ url('/editar/'.$usuario->id) }}"></a>
                                <button uk-toggle="target: #my-id-{{$usuario->id}}" type="button" class="uk-icon-button uk-margin-small-right uk-button-danger" uk-icon="trash"></button>
                                <div id="my-id-{{$usuario->id}}" uk-modal>
                                    <div class="uk-modal-dialog uk-modal-body">
                                        <h2 class="uk-text-large">¿ Desea borrar a {{$usuario->nombre}} ?</h2>
                                        <form action="{{ url('/eliminar/'.$usuario->id) }}" method="post">
                                        {{ csrf_field() }}
                                        <div class="uk-modal-footer uk-text-right">
                                            <button class="uk-button uk-button-default uk-modal-close" type="button">Cancelar</button>
                                            <button type="submit" class="uk-button uk-button-primary">Borrar</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </th>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                
        </div>
    </body>
</html>